﻿namespace LibplctagWrapper
{
    public enum CpuType
    {
        LGX,
        SLC,
        PLC5
    }
}
