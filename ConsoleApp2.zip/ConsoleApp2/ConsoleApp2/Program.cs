﻿using LibplctagWrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        private const int DataTimeout = 5000;
        static void Main(string[] args)
        { 
            try
            {
                // creates a tag to read B3:0, 1 item, from SLC ip address 192.168.0.100
                var tag = new Tag("192.168.0.100", CpuType.SLC, "B3:0", DataType.Int16, 1);

                using (var client = new Libplctag())
                {
                    client.AddTag(tag);

                    while (client.GetStatus(tag) == Libplctag.PLCTAG_STATUS_PENDING)
                    {
                        Thread.Sleep(100);
                    }
                    if (client.GetStatus(tag) != Libplctag.PLCTAG_STATUS_OK)
                    {
                        Console.WriteLine("Error");
                        return;
                    }
                    // Execute the read
                    var result = client.ReadTag(tag, DataTimeout);

                    // Check the read operation result
                    if (result != Libplctag.PLCTAG_STATUS_OK)
                    {
                        Console.WriteLine($"ERROR: Unable to read the data! Got error code {result}: {client.DecodeError(result)}\n");
                        return;
                    }
                    // Convert the data
                    var n7_0 = client.GetInt16Value(tag, 0 * tag.ElementSize);

                    // print to console
                    Console.WriteLine("TestDintArray0: " + n7_0);
                }
            }
            finally
            {
                Console.ReadKey();
            }
        }
    }
}
